"""CLI package for ansible-neo commands."""
