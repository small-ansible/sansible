"""
Ansible Neo Connections Module

Connection plugins for SSH and WinRM.
"""

from ansible_neo.connections.base import Connection, RunResult, create_connection_factory
from ansible_neo.connections.local import LocalConnection

__all__ = [
    'Connection',
    'RunResult',
    'LocalConnection',
    'create_connection_factory',
]
