"""
Ansible Neo Error Classes

All custom exceptions for clear error handling and exit codes.
"""

from typing import Optional


class NeoError(Exception):
    """Base exception for all Ansible Neo errors."""
    
    exit_code: int = 1
    
    def __init__(self, message: str, details: Optional[str] = None):
        self.message = message
        self.details = details
        super().__init__(message)
    
    def __str__(self) -> str:
        if self.details:
            return f"{self.message}\n  Details: {self.details}"
        return self.message


class ParseError(NeoError):
    """Error parsing inventory, playbook, or other input files."""
    
    exit_code: int = 3
    
    def __init__(
        self, 
        message: str, 
        file_path: Optional[str] = None,
        line: Optional[int] = None,
        details: Optional[str] = None
    ):
        self.file_path = file_path
        self.line = line
        location = ""
        if file_path:
            location = f" in {file_path}"
            if line:
                location += f" at line {line}"
        super().__init__(f"Parse error{location}: {message}", details)


class UnsupportedFeatureError(NeoError):
    """Error when playbook uses a feature not supported by Neo."""
    
    exit_code: int = 4
    
    def __init__(self, feature: str, suggestion: Optional[str] = None):
        self.feature = feature
        msg = f"Unsupported feature: {feature}"
        if suggestion:
            msg += f"\n  Suggestion: {suggestion}"
        super().__init__(msg)


class ConnectionError(NeoError):
    """Error connecting to a remote host."""
    
    exit_code: int = 2
    
    def __init__(
        self, 
        host: str, 
        message: str,
        connection_type: Optional[str] = None,
        details: Optional[str] = None
    ):
        self.host = host
        self.connection_type = connection_type
        conn_info = f" ({connection_type})" if connection_type else ""
        super().__init__(f"Connection to {host}{conn_info} failed: {message}", details)


class ModuleError(NeoError):
    """Error executing a module on a host."""
    
    exit_code: int = 2
    
    def __init__(
        self,
        module: str,
        host: str,
        message: str,
        rc: Optional[int] = None,
        stdout: Optional[str] = None,
        stderr: Optional[str] = None,
    ):
        self.module = module
        self.host = host
        self.rc = rc
        self.stdout = stdout
        self.stderr = stderr
        
        details_parts = []
        if rc is not None:
            details_parts.append(f"rc={rc}")
        if stderr:
            details_parts.append(f"stderr: {stderr[:200]}")
        
        super().__init__(
            f"Module '{module}' failed on {host}: {message}",
            "; ".join(details_parts) if details_parts else None
        )


class TemplateError(NeoError):
    """Error rendering a Jinja2 template."""
    
    exit_code: int = 3
    
    def __init__(
        self,
        message: str,
        template: Optional[str] = None,
        variable: Optional[str] = None,
    ):
        self.template = template
        self.variable = variable
        
        details = None
        if template:
            # Truncate long templates
            truncated = template[:100] + "..." if len(template) > 100 else template
            details = f"Template: {truncated}"
        
        super().__init__(f"Template error: {message}", details)


class HostFailedError(NeoError):
    """A host has failed during playbook execution."""
    
    exit_code: int = 2
    
    def __init__(self, host: str, task: str, message: str):
        self.host = host
        self.task = task
        super().__init__(f"Host {host} failed at task '{task}': {message}")


class InventoryError(ParseError):
    """Error in inventory file or host resolution."""
    
    def __init__(self, message: str, file_path: Optional[str] = None):
        super().__init__(message, file_path=file_path)
