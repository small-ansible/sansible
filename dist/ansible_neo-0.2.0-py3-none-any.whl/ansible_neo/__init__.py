"""
Ansible Neo: Minimal Ansible-compatible playbook runner.

A lightweight alternative to Ansible for running simple playbooks
on Windows and Linux hosts via SSH and WinRM.
"""

__version__ = "0.1.0"
__author__ = "Ansible-Neo Contributors"

# Version info tuple for programmatic access
VERSION_INFO = (0, 1, 0)

# Main CLI entry point
from ansible_neo.cli import main

__all__ = ['main', '__version__', 'VERSION_INFO']
