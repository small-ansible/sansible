"""
Ansible-Neo Vendor Package.

This package contains vendored pure-Python implementations of functionality
that would otherwise require compiled dependencies.

All vendored code is:
1. Under permissive licenses (MIT, BSD, Apache)
2. Documented in /docs/agent/licenses/THIRD_PARTY.md
3. Modified only as necessary for our use case

Current vendored modules:
- (None yet - modules will be added as needed)

Planned for future milestones:
- ssh/ - Pure Python SSH client (Phase B, optional)
- ntlm/ - Pure Python NTLM authentication (M4)
- winrm/ - Pure Python WinRM/WSMan protocol (M4)
"""
